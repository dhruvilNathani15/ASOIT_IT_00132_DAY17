<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
$a=5;
$b=5;
echo  " addition of $a and $b =",$a+$b;
echo "<br>";
echo "sum of multipliction=",$a*$b;
echo"<br>";
echo  "sum of substraction=",$a-$b;
echo "<br>";
echo  "sum of divison=",$a/$b;
echo "<br>";
?>

<?php
$a=5;
if($a % 2 ==  0){
    echo "it is even number";
}
else{
    echo "it is odd number";
}
echo "<br>";
?>

</body>
</html>